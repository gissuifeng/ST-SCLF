--------flow_data_all_2018.csv--------

There are 2610393 records in file flow_data_all_2018.csv
data time interval: 2018/01/01-2018/12/31

data structure:

RecordID, from_time, origin_city_code, to_time, destination_city_code, value
1, 2018-01-01 12:00:00, 221, 2018-01-01 12:00:00, 361, 77


RecordID: Unique id for each flow unit.
from_time: Happy time of flow unit.
origin_city_code: code of source city in current flow unit.
to_time: Happy time of flow unit.
destination_city_code: code of target city in current flow unit.
value: total population from source city to target city.


--------spatial_neighbor_metrix.csv--------
There are about 300 cities included in file, and spatial neighbor metrix is created for each city.A Queen rule is used in metrix.


--------flow_data_sub_2018--------
A sub dataset extracted from flow_data_all_2018.csv
